// Страница одного аниме: данные, жанры, рейтинг, отзывы, форма.
// Логику пишешь ты. Ниже — что должно работать, по шагам.

const API = "http://127.0.0.1:8000";

// 0. id из адреса страницы anime.html?id=9
//    Подсказка: new URLSearchParams(window.location.search).get("id")

// 1. Аниме.
//    GET /anime/{id}
//    404 → спрячь #anime и .reviews-layout, покажи #page-error.
//    Иначе заполни #title, #cover-title, #year, #episodes, #status
//    (ongoing → «Выходит», finished → «Вышло», announced → «Анонс»),
//    data-status у #cover, document.title = `${title} — AnimeList`,
//    и <li> на каждый жанр в #genres.

// 2. Рейтинг.
//    GET /anime/{id}/rating
//    average_score === null → «—» и «Оценок пока нет».
//    Иначе #rating-score = average_score, #rating-count = «по N отзывам».

// 3. Отзывы.
//    GET /anime/{id}/reviews?limit=5&offset=...
//    Клонируй <template id="review-item">: .review-score, .review-author, .review-text
//    (text может быть null — тогда оставь пустым, CSS сам спрячет абзац).
//    Пусто на первой странице → покажи #reviews-empty.
//    Пагинация как на главной: #reviews-prev, #reviews-next, #reviews-page.

// 4. Форма отзыва.
//    submit → preventDefault, собери { author, score: Number(...), text } (пустой текст → null).
//    POST /anime/{id}/reviews с headers: { "Content-Type": "application/json" }.
//    201 → #form-message data-type="success" «Отзыв опубликован»,
//          очистить форму, перезагрузить рейтинг и отзывы.
//    422 → data-type="error", понятный текст: не заполнено имя или не выбрана оценка.
//    404 → «Аниме удалено, отзыв не сохранён».
//    Проверь на фронте до отправки: имя не пустое и оценка выбрана.
