// Главная страница: каталог, фильтры, топ.
// Логику пишешь ты. Ниже — что должно работать, по шагам.

const API = "http://127.0.0.1:8000";

// 1. Топ.
//    GET /anime/top → для каждого аниме клонируй <template id="top-item">,
//    заполни .top-score (average_score), .top-title, .top-count («3 отзыва»),
//    ссылку href = `anime.html?id=${id}` и добавь в #top-list.

// 2. Жанры в фильтр.
//    GET /genres → <option value="action">action</option> в <select id="genre">.

// 3. Список аниме.
//    Собери query-строку из формы #filters + пагинации (limit, offset).
//    Подсказка: new URLSearchParams(), и не добавляй пустые значения.
//    GET /anime?... → для каждого аниме клонируй <template id="anime-card">,
//    поставь data-status, заполни .spine-year, .spine-title, .spine-status
//    (ongoing → «Выходит», finished → «Вышло», announced → «Анонс»),
//    ссылку на anime.html?id=...
//    Пустой ответ → покажи #empty (hidden = false).
//    В #list-status пиши «Загрузка…» до ответа и текст ошибки, если !response.ok.

// 4. Форма фильтров.
//    submit → event.preventDefault(), сбросить страницу на первую, загрузить список.
//    reset  → после сброса тоже перезагрузить список.

// 5. Пагинация.
//    #prev-page / #next-page меняют offset на ±limit и перезагружают список.
//    «Назад» недоступна на первой странице (disabled = true).
//    «Вперёд» недоступна, если пришло меньше limit аниме.
//    #page-number — «Страница N».
